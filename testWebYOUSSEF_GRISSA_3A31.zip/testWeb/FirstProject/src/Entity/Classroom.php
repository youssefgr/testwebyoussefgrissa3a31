<?php

namespace App\Entity;

use App\Repository\ClassroomRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ClassroomRepository::class)]
class Classroom
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column]
    private ?int $nbTable = null;

    //#[ORM\OneToMany(mappedBy: 'class_room', targetEntity: Student::class, orphanRemoval: true)]
    

    #[ORM\OneToMany(mappedBy: 'name_class', targetEntity: Student::class, orphanRemoval: true)]
    private Collection $students;

    public function __construct()
    {
        
        $this->students = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function __toString()
    {
        return $this->getName();
    }
    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getNbTable(): ?int
    {
        return $this->nbTable;
    }

    public function setNbTable(int $nbTable): static
    {
        $this->nbTable = $nbTable;

        return $this;
    }

  
   

    /**
     * @return Collection<int, Student>
     */
    public function getstudents(): Collection
    {
        return $this->students;
    }

    public function addstudents(Student $students): static
    {
        if (!$this->students->contains($students)) {
            $this->students->add($students);
            $students->setNameClass($this);
        }

        return $this;
    }

    public function removestudents(Student $students): static
    {
        if ($this->students->removeElement($students)) {
            // set the owning side to null (unless already changed)
            if ($students->getNameClass() === $this) {
                $students->setNameClass(null);
            }
        }

        return $this;
    }
}
