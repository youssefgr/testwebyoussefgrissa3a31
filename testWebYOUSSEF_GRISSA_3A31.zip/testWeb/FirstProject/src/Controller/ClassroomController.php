<?php

namespace App\Controller;

use App\Entity\Classroom;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Student;
use App\Form\ClassroomType;
use App\Form\StudentType;
use App\Repository\StudentRepository;
use App\Repository\ClassroomRepository;
use Symfony\Component\HttpFoundation\Request;

class ClassroomController extends AbstractController
{
    #[Route('/classroom', name: 'app_classroom')]
    public function index(ClassroomRepository $authorRepository): Response
    {
        return $this->render('classroom/affichageClassroom.html.twig', [
            'controller_name' => 'ClassroomController',
        ]);
    }
    #[Route('/classroom/fnew', name: 'app_classroom_fnew')]
    public function fnew(Request $request ,EntityManagerInterface $entityManagerInterface): Response
    {
        $classroom= new Classroom();
        $form=$this->createForm(ClassroomType::class,$classroom);
        $form->handleRequest($request);
        if($form->isSubmitted()){
           
            $entityManagerInterface->persist($classroom);
            $entityManagerInterface->flush();
            return $this->redirectToRoute('app_classroom');
        
        
    }
    return $this->renderForm('classroom/new.html.twig',['form'=>$form,'info'=>'Add classroom']);
    }

   #[Route('/classroom', name: 'app_classroom')]
    public function showbook(ClassroomRepository $authorRepository): Response
    {
        $classroomss=$authorRepository->findAll();
        
        return $this->render('classroom/affichageclassroom.html.twig', [
            'classrooms' => $classroomss,
            
        ]);
    }

#[Route('/classroom/fedit/{id}', name: 'app_classroom_fedit')]
public function fedit(Request $request,$id ,EntityManagerInterface $entityManagerInterface ,ClassroomRepository $classroomRepository)
{
   $classroom = $classroomRepository->find($id);
   $form=$this->createForm(ClassroomType::class,$classroom);
   $form->handleRequest($request);
   if($form->isSubmitted())
   {
   $entityManagerInterface->persist($classroom);
   $entityManagerInterface->flush();
   return $this->redirectToRoute('app_classroom');
   }
   return $this->renderForm('classroom/new.html.twig',['form'=>$form, 'info'=>'Edit classroom']);
   dump($classroom);
   die();
}
#[Route('/classroom/delete/{id}', name: 'app_classroom_delete')]
    public function delete($id ,EntityManagerInterface $entityManagerInterface , ClassroomRepository $classroomRepository)
    {
       $classroom = $classroomRepository->find($id);
       $entityManagerInterface->remove($classroom);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_classroom');
       dd($classroom);
       
    }
}
