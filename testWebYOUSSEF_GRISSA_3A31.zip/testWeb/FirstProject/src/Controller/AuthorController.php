<?php

namespace App\Controller;

use App\Entity\Author;

use App\Form\AddAuthorType;
use App\Form\EditAuthorType;
use App\Repository\AuthorRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Symfony\Component\Routing\Annotation\Route;

class AuthorController extends AbstractController
{
    #[Route('/author', name: 'app_author')]
    public function index(AuthorRepository $authorRepository): Response
    {
        $authorss=$authorRepository->findAll();
        $authors = array(
            array('id' => 1, 'picture' => '/images/Victor-Hugo.jpg','username' => 'Victor Hugo', 'email' =>'victor.hugo@gmail.com ', 'nb_books' => 100),
            array('id' => 2, 'picture' => '/images/william-shakespeare.jpg','username' => ' William Shakespeare', 'email' =>' william.shakespeare@gmail.com', 'nb_books' => 200 ),
            array('id' => 3, 'picture' => '/images/Taha_Hussein.jpg','username' => 'Taha Hussein', 'email' =>'taha.hussein@gmail.com', 'nb_books' => 300),
        
            );
        return $this->render('author/affichage.html.twig', [
            'controller_name' => 'AuthorController',
            'authors' => $authorss,
            
        ]);
    }
   

   
    #[Route('/author/fedit/{id}', name: 'app_author_fedit')]
    public function fedit(Request $request,$id ,EntityManagerInterface $entityManagerInterface , AuthorRepository $authorRepository)
    {
       $author = $authorRepository->find($id);
       $form=$this->createForm(EditAuthorType::class,$author);
       $form->handleRequest($request);
       if($form->isSubmitted())
       {
       $entityManagerInterface->persist($author);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_author');
       }
       return $this->renderForm('author/new.html.twig',['form'=>$form, 'info'=>'Edit Author']);
       dump($author);
       die();
    }
    #[Route('/author/edit/{id}', name: 'app_author_edit')]
        public function Edit_author($id, EntityManagerInterface $entityManagerInterface, AuthorRepository $authorRepository )
        {
    
            $author= $authorRepository->find($id);
            $author->setName("abc");
            $author->setNbBooks(69);
           $entityManagerInterface->persist($author);
               $entityManagerInterface->flush();
               dump($author);
               die();
               //dd($author) nafsha dump w die
            
        
        }
    #[Route('/author/fnew', name: 'app_author_fnew')]
    public function fnew(Request $request ,EntityManagerInterface $entityManagerInterface)
    {
        $author= new Author();
        $form=$this->createForm(AddAuthorType::class,$author);
        $form->handleRequest($request);
        if($form->isSubmitted()){
            $entityManagerInterface->persist($author);
            $entityManagerInterface->flush();
            return $this->redirectToRoute('app_author');
        }
        return $this->renderForm('author/new.html.twig',['form'=>$form,'info'=>'Add Author']);
    
    }
    #[Route('/author/new', name: 'app_author_new')]
    public function new(EntityManagerInterface $entityManagerInterface)
    {
        $author= new Author();
        $author->setName("abc");
        $author->setNbBooks(69);
       $entityManagerInterface->persist($author);
           $entityManagerInterface->flush();
    
           dump($author);
           die();
        
    
    }
    
    
    

    #[Route('/author/delete/{id}', name: 'app_author_delete')]
    public function Delete_author($id, EntityManagerInterface $entityManagerInterface, AuthorRepository $authorRepository )
    {
        
        $author= $authorRepository->find($id);
       $entityManagerInterface->remove($author);
           $entityManagerInterface->flush();
    
           
           return $this->redirectToRoute('app_author');
           dump($author);
           die();
    }
   
    #[Route('/author/{id}', name: 'app_author3')]
    public function authorDetails($id): Response
    {
        $author=null;
        $authors = array(
            array('id' => 1, 'picture' => '/images/Victor-Hugo.jpg','username' => 'Victor Hugo', 'email' =>'victor.hugo@gmail.com ', 'nb_books' => 100),
            array('id' => 2, 'picture' => '/images/william-shakespeare.jpg','username' => ' William Shakespeare', 'email' =>' william.shakespeare@gmail.com', 'nb_books' => 200 ),
            array('id' => 3, 'picture' => '/images/Taha_Hussein.jpg','username' => 'Taha Hussein', 'email' =>'taha.hussein@gmail.com', 'nb_books' => 300),
        );

        foreach($authors as $auth){

         if($id== $auth['id'])
         {
         $author=$auth;
         break;
         }

        }
        return $this->render('author/showAuthors.html.twig', [
            'controller_name' => 'AuthorController',
            'id' => $id,
            'author' => $author,
        ]);
    }
 




   
}



