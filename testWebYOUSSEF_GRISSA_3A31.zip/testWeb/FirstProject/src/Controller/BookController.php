<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Author;
use App\Entity\Book;
use App\Form\BookType;
use App\Repository\AuthorRepository;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\BookRepository;
use Symfony\Component\HttpFoundation\Request;

class BookController extends AbstractController
{
    #[Route('/book/fnew', name: 'app_book_fnew')]
    public function fnew(Request $request ,EntityManagerInterface $entityManagerInterface): Response
    {
        $book= new Book();
        $form=$this->createForm(BookType::class,$book);
        $form->handleRequest($request);
        if($form->isSubmitted()){
            $authorId = $form->get('author')->getData();
            $author = $entityManagerInterface->getRepository(Author::class)->find($authorId);
            if ($author) {
                $book->setAuthor($author);
                $author->setNbBooks($author->getNbBooks() + 1);
            $entityManagerInterface->persist($book);
            $entityManagerInterface->flush();
            return $this->redirectToRoute('app_book');
        }
        
    }
    return $this->renderForm('book/new.html.twig',['form'=>$form,'info'=>'Add Book']);
    }

   #[Route('/book', name: 'app_book')]
    public function showbook(BookRepository $authorRepository): Response
    {
        $bookss=$authorRepository->findAll();
        
        return $this->render('book/affichageBooks.html.twig', [
            'controller_name' => 'BookController',
            'books' => $bookss,
            
        ]);
    }

#[Route('/book/fedit/{id}', name: 'app_book_fedit')]
public function fedit(Request $request,$id ,EntityManagerInterface $entityManagerInterface ,BookRepository $authorRepository)
{
   $author = $authorRepository->find($id);
   $form=$this->createForm(BookType::class,$author);
   $form->handleRequest($request);
   if($form->isSubmitted())
   {
   $entityManagerInterface->persist($author);
   $entityManagerInterface->flush();
   return $this->redirectToRoute('app_book');
   }
   return $this->renderForm('book/new.html.twig',['form'=>$form, 'info'=>'Edit Book']);
   dump($author);
   die();
}
#[Route('/book/delete/{id}', name: 'app_book_delete')]
    public function delete($id ,EntityManagerInterface $entityManagerInterface , BookRepository $authorRepository)
    {
       $author = $authorRepository->find($id);
       $entityManagerInterface->remove($author);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_book');
       dd($author);
       
    }
}