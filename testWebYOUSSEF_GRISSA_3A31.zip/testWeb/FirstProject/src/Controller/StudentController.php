<?php

namespace App\Controller;

use App\Entity\Student;
use App\Form\StudentType;
use App\Entity\Classroom;
use App\Form\ClassroomType;
use App\Repository\StudentRepository;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\ClassroomRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;

class StudentController extends AbstractController
{

    #[Route('/student/fdelete/{id}', name: 'app_student_fdelete')]
    public function deleteStudent($id ,EntityManagerInterface $entityManagerInterface , StudentRepository $StudentRepository): Response
    {
        $student= $StudentRepository->find($id);
        $entityManagerInterface->remove($student);
            $entityManagerInterface->flush();
     
            
            return $this->redirectToRoute('app_student');
            dump($student);
            die();
    }


    #[Route('/student/fedit/{id}', name: 'app_student_fedit')]
    public function EditStudent(Request $request,$id ,EntityManagerInterface $entityManagerInterface , StudentRepository $StudentRepository): Response
    {
        $student = $StudentRepository->find($id);
        $form=$this->createForm(StudentType::class,$student);
        $form->handleRequest($request);
        if($form->isSubmitted())
        {
            $name_class_id = $form->get('classroom')->getData();
           $classroom = $entityManagerInterface->getRepository(Classroom::class)->find($name_class_id);
           if ($classroom) {
               $student->setNameClass($classroom);
        $entityManagerInterface->persist($student);
        $entityManagerInterface->flush();
        return $this->redirectToRoute('app_student');
        }
    }
        return $this->renderForm('student/new.html.twig',['form'=>$form, 'info'=>'Edit student']);
        dump($student);
        die();
    }
    #[Route('/student', name: 'app_student')]
    public function index(StudentRepository $StudentRepository): Response
    {
        $studentss=$StudentRepository->findAll();
        return $this->render('student/afficherStudent.html.twig', [
            'controller_name' => 'StudentController',
            'classe' => '3a31',
            'students' => $studentss,


        ]);
    }
    #[Route('/student/fnew', name: 'app_student_fnew')]
    public function AfficherStudent(Request $request ,EntityManagerInterface $entityManagerInterface)
    {
        $student= new Student();
        $form=$this->createForm(StudentType::class,$student);
        $form->handleRequest($request);
        if($form->isSubmitted()){
            $entityManagerInterface->persist($student);
            $entityManagerInterface->flush();
            return $this->redirectToRoute('app_student');
        }
        return $this->renderForm('student/new.html.twig',['form'=>$form,'info'=>'Add student']);
    }


   


    


    
}


